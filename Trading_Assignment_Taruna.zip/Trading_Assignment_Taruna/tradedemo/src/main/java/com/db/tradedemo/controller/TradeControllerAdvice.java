package com.db.tradedemo.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.db.tradedemo.exception.InvalidTradeException;



@ControllerAdvice
@RequestMapping(produces = "application/json")
public class TradeControllerAdvice extends ResponseEntityExceptionHandler{
    @ExceptionHandler(InvalidTradeException.class)
    public ResponseEntity<Object> notFoundException(final InvalidTradeException e) {
        return new ResponseEntity<>(e.getId(), HttpStatus.NOT_ACCEPTABLE);
    }

   

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> assertionException(final IllegalArgumentException e) {
        return new ResponseEntity<>(e.getLocalizedMessage(), HttpStatus.NOT_ACCEPTABLE);
    }



}
